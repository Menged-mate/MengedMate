import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import authService from '../../services/authService';
import stationOwnerService from '../../services/stationOwnerService';
import StationOwnerProfileUpdate from './StationOwnerProfileUpdate';
import StationOwnerChangePassword from './StationOwnerChangePassword';
import StationOwnerWallet from './StationOwnerWallet';
import StationOwnerSettings from './StationOwnerSettings';
import './StationOwner.css';

const StationOwnerDashboard = () => {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('profile');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        // Get user data
        const userData = authService.getCurrentUser();
        if (!userData) {
          navigate('/login');
          return;
        }
        setUser(userData);

        // Get station owner profile
        const profileData = await stationOwnerService.getProfile();
        setProfile(profileData);

        // Check if profile is completed
        if (!profileData.is_profile_completed) {
          navigate('/station-owners/complete-profile');
          return;
        }

        // Check verification status
        if (profileData.verification_status === 'pending') {
          navigate('/station-owners/pending-verification');
          return;
        }
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Failed to load dashboard data. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [navigate]);

  const handleLogout = () => {
    authService.logout();
    navigate('/login');
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };

  if (loading) {
    return (
      <div className="dashboard-loading">
        <div className="spinner"></div>
        <p>Loading dashboard...</p>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      {/* Top Navigation Bar */}
      <nav className="navbar">
        <div className="navbar-container">
          <div className="navbar-logo">
            <i className="fas fa-charging-station"></i>
            <span>Mengedmate</span>
            {profile && profile.verification_status === 'verified' && (
              <div className="verified-badge">
                <i className="fas fa-check-circle"></i> Verified
              </div>
            )}
          </div>

          <div className="navbar-links">
            <ul>
              <li
                className={activeTab === 'profile' ? 'active' : ''}
                onClick={() => handleTabChange('profile')}
              >
                <i className="fas fa-user"></i> Profile
              </li>
              <li
                className={activeTab === 'stations' ? 'active' : ''}
                onClick={() => handleTabChange('stations')}
              >
                <i className="fas fa-charging-station"></i> My Stations
              </li>
              <li
                className={activeTab === 'wallet' ? 'active' : ''}
                onClick={() => handleTabChange('wallet')}
              >
                <i className="fas fa-wallet"></i> Wallet
              </li>
              <li
                className={activeTab === 'analytics' ? 'active' : ''}
                onClick={() => handleTabChange('analytics')}
              >
                <i className="fas fa-chart-line"></i> Analytics
              </li>
              <li
                className={activeTab === 'settings' ? 'active' : ''}
                onClick={() => handleTabChange('settings')}
              >
                <i className="fas fa-cog"></i> Settings
              </li>
            </ul>
          </div>

          <div className="navbar-user">
            <div className="user-avatar-container">
              <div className="user-avatar" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                {user?.first_name?.charAt(0) || user?.email?.charAt(0)}
              </div>
              {profile && profile.verification_status === 'verified' && (
                <div className="avatar-verified-badge">
                  <i className="fas fa-check-circle"></i>
                </div>
              )}
            </div>
            {mobileMenuOpen && (
              <div className="user-dropdown">
                <div className="user-info">
                  <h3>
                    {user?.first_name} {user?.last_name}
                    {profile && profile.verification_status === 'verified' && (
                      <span className="verified-badge-small">
                        <i className="fas fa-check-circle"></i>
                      </span>
                    )}
                  </h3>
                  <p>{user?.email}</p>
                  {profile && profile.company_name && (
                    <p className="company-name">{profile.company_name}</p>
                  )}
                </div>
                <ul>
                  <li className={activeTab === 'profile' ? 'active' : ''} onClick={() => handleTabChange('profile')}>
                    <i className="fas fa-user"></i> Profile
                  </li>
                  <li className={activeTab === 'settings' ? 'active' : ''} onClick={() => handleTabChange('settings')}>
                    <i className="fas fa-cog"></i> Settings
                  </li>
                  <li className={activeTab === 'password' ? 'active' : ''} onClick={() => handleTabChange('password')}>
                    <i className="fas fa-key"></i> Change Password
                  </li>
                  <li onClick={handleLogout}>
                    <i className="fas fa-sign-out-alt"></i> Logout
                  </li>
                </ul>
              </div>
            )}
          </div>

          <div className="mobile-menu-button" onClick={toggleMobileMenu}>
            <i className={mobileMenuOpen ? 'fas fa-times' : 'fas fa-bars'}></i>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="mobile-menu">
          <ul>
            <li
              className={activeTab === 'profile' ? 'active' : ''}
              onClick={() => handleTabChange('profile')}
            >
              <i className="fas fa-user"></i> Profile
            </li>
            <li
              className={activeTab === 'stations' ? 'active' : ''}
              onClick={() => handleTabChange('stations')}
            >
              <i className="fas fa-charging-station"></i> My Stations
            </li>
            <li
              className={activeTab === 'wallet' ? 'active' : ''}
              onClick={() => handleTabChange('wallet')}
            >
              <i className="fas fa-wallet"></i> Wallet
            </li>
            <li
              className={activeTab === 'analytics' ? 'active' : ''}
              onClick={() => handleTabChange('analytics')}
            >
              <i className="fas fa-chart-line"></i> Analytics
            </li>
            <li
              className={activeTab === 'settings' ? 'active' : ''}
              onClick={() => handleTabChange('settings')}
            >
              <i className="fas fa-cog"></i> Settings
            </li>
            <li onClick={handleLogout}>
              <i className="fas fa-sign-out-alt"></i> Logout
            </li>
          </ul>
        </div>
      )}

      {/* Dashboard Content */}
      <div className="dashboard-content">
        {error && <div className="dashboard-error">{error}</div>}

        {activeTab === 'profile' && (
          <StationOwnerProfileUpdate
            user={user}
            profile={profile}
            onProfileUpdate={(updatedProfile) => setProfile(updatedProfile)}
          />
        )}

        {activeTab === 'stations' && (
          <div className="coming-soon">
            <i className="fas fa-tools"></i>
            <h2>Coming Soon</h2>
            <p>The station management feature is under development.</p>
          </div>
        )}

        {activeTab === 'wallet' && (
          <StationOwnerWallet />
        )}

        {activeTab === 'analytics' && (
          <div className="coming-soon">
            <i className="fas fa-chart-pie"></i>
            <h2>Coming Soon</h2>
            <p>Analytics features will be available in a future update.</p>
          </div>
        )}

        {activeTab === 'settings' && (
          <StationOwnerSettings />
        )}

        {activeTab === 'password' && (
          <StationOwnerChangePassword />
        )}
      </div>
    </div>
  );
};

export default StationOwnerDashboard;

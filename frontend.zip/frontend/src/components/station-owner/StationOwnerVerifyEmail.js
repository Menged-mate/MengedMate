import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import stationOwnerService from '../../services/stationOwnerService';
import '../auth/Auth.css';

const StationOwnerVerifyEmail = () => {
  const [verificationCode, setVerificationCode] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);
  const [countdown, setCountdown] = useState(0);

  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Get email from location state
    if (location.state && location.state.email) {
      setEmail(location.state.email);
    }
  }, [location]);

  useEffect(() => {
    // Countdown timer for resend button
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const handleChange = (e) => {
    setVerificationCode(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      const response = await stationOwnerService.verifyEmail(email, verificationCode);
      setSuccess('Email verified successfully!');

      // Navigate to profile completion page after 2 seconds
      setTimeout(() => {
        navigate('/station-owners/complete-profile');
      }, 2000);
    } catch (err) {
      console.error('Verification error:', err);

      if (typeof err === 'object' && err !== null) {
        // Handle object errors by converting to string
        const errorMessage = Object.entries(err)
          .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`)
          .join('; ');
        setError(errorMessage || 'Verification failed. Please try again.');
      } else {
        // Default error message
        setError(err.message || 'Verification failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleResendCode = async () => {
    setError('');
    setResendLoading(true);

    try {
      await stationOwnerService.resendVerificationCode(email);
      setSuccess('Verification code has been resent to your email.');
      setCountdown(60); // Set 60 seconds countdown
    } catch (err) {
      console.error('Resend verification error:', err);

      if (typeof err === 'object' && err !== null) {
        // Handle object errors by converting to string
        const errorMessage = Object.entries(err)
          .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`)
          .join('; ');
        setError(errorMessage || 'Failed to resend verification code. Please try again.');
      } else {
        // Default error message
        setError(err.message || 'Failed to resend verification code. Please try again.');
      }
    } finally {
      setResendLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-header">
          <div className="auth-logo">
            <i className="fas fa-charging-station" style={{ fontSize: '48px', color: '#4a6cf7' }}></i>
          </div>
          <h2>Verify Your Email</h2>
          <p>We've sent a verification code to your email</p>
        </div>

        {error && <div className="auth-error">{error}</div>}
        {success && <div className="auth-success">{success}</div>}

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              disabled={location.state && location.state.email}
            />
          </div>

          <div className="form-group">
            <label htmlFor="verificationCode">Verification Code</label>
            <input
              type="text"
              id="verificationCode"
              name="verificationCode"
              placeholder="Enter 6-digit code"
              value={verificationCode}
              onChange={handleChange}
              required
              maxLength="6"
            />
          </div>

          <button type="submit" className="auth-button" disabled={loading}>
            {loading ? 'Verifying...' : 'Verify Email'}
          </button>
        </form>

        <div className="resend-code">
          Didn't receive the code?{' '}
          <button
            className="resend-button"
            onClick={handleResendCode}
            disabled={resendLoading || countdown > 0}
          >
            {countdown > 0
              ? `Resend in ${countdown}s`
              : resendLoading
              ? 'Sending...'
              : 'Resend Code'}
          </button>
        </div>

        <div className="auth-footer">
          <Link to="/station-owners/register" className="back-link">
            <i className="fas fa-arrow-left"></i> Back to Registration
          </Link>
        </div>
      </div>
    </div>
  );
};

export default StationOwnerVerifyEmail;

import React from 'react';
import './StationOwner.css';

const StationOwnerSettings = () => {
  return (
    <div className="settings-container">
      <div className="dashboard-header">
        <h1>Settings</h1>
        <p>Manage your Mengedmate account settings and preferences</p>
      </div>

      <div className="coming-soon">
        <i className="fas fa-cogs"></i>
        <h2>Settings Coming Soon</h2>
        <p>The settings feature is under development. You'll soon be able to customize your account preferences, notification settings, and more.</p>

        <div className="feature-preview">
          <h3>Upcoming Features:</h3>
          <ul>
            <li><i className="fas fa-bell"></i> Notification Preferences</li>
            <li><i className="fas fa-globe"></i> Language and Region</li>
            <li><i className="fas fa-shield-alt"></i> Privacy and Security</li>
            <li><i className="fas fa-palette"></i> Theme Customization</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default StationOwnerSettings;

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import stationOwnerService from '../../services/stationOwnerService';
import authService from '../../services/authService';
import '../auth/Auth.css';
import './StationOwner.css';

const StationOwnerPendingVerification = () => {
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is authenticated
    if (!authService.isAuthenticated()) {
      navigate('/login');
      return;
    }

    // Fetch station owner profile
    const fetchProfile = async () => {
      try {
        const profileData = await stationOwnerService.getProfile();
        setProfile(profileData);

        // If profile is not completed, redirect to complete profile page
        if (!profileData.is_profile_completed) {
          navigate('/station-owners/complete-profile');
          return;
        }

        // If profile is verified, redirect to dashboard
        if (profileData.verification_status === 'verified') {
          navigate('/dashboard'); // For now, redirect to main dashboard
          return;
        }

        // If profile is rejected, redirect to rejected page
        if (profileData.verification_status === 'rejected') {
          navigate('/dashboard'); // For now, redirect to main dashboard
          return;
        }
      } catch (err) {
        console.error('Error fetching profile:', err);
        setError('Failed to load profile. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();

    // Poll for profile status changes every 30 seconds
    const intervalId = setInterval(fetchProfile, 30000);

    return () => clearInterval(intervalId);
  }, [navigate]);

  const handleLogout = () => {
    authService.logout();
    navigate('/login');
  };

  if (loading) {
    return (
      <div className="auth-container">
        <div className="auth-card">
          <div className="loading-spinner">Loading...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-header">
          <div className="auth-logo">
            <i className="fas fa-charging-station" style={{ fontSize: '48px', color: '#4a6cf7' }}></i>
          </div>
          <h2>Verification Pending</h2>
          <p>Your account is currently under review</p>
        </div>

        {error && <div className="auth-error">{error}</div>}

        <div className="verification-status pending">
          <i className="fas fa-clock"></i>
          <h3>Verification in Progress</h3>
          <p>
            Thank you for submitting your information. Our team is currently reviewing your documents
            to verify your account. This process typically takes 1-3 business days.
          </p>
          <p>
            You will receive an email notification once your account has been verified, and you'll be
            able to start adding your charging stations.
          </p>
        </div>

        <div className="verification-actions">
          <button className="secondary-button" onClick={() => navigate('/dashboard')}>
            Go to Dashboard
          </button>
          <button className="outline-button" onClick={handleLogout}>
            Logout
          </button>
        </div>

        <div className="verification-contact">
          <p>
            If you have any questions or need assistance, please contact our support team at{' '}
            <a href="mailto:support@evfinder.com">support@evfinder.com</a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default StationOwnerPendingVerification;

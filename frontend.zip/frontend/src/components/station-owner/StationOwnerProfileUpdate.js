import React, { useState, useEffect } from 'react';
import stationOwnerService from '../../services/stationOwnerService';
import './StationOwner.css';

const StationOwnerProfileUpdate = ({ user, profile, onProfileUpdate }) => {
  const [formData, setFormData] = useState({
    company_name: '',
    business_registration_number: '',
    website: '',
    description: '',
  });

  const [files, setFiles] = useState({
    business_license: null,
    id_proof: null,
    utility_bill: null,
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Update form data when profile prop changes
  useEffect(() => {
    if (profile) {
      setFormData({
        company_name: profile.company_name || '',
        business_registration_number: profile.business_registration_number || '',
        website: profile.website || '',
        description: profile.description || '',
      });
    }
  }, [profile]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleFileChange = (e) => {
    const { name, files: fileList } = e.target;
    if (fileList && fileList.length > 0) {
      setFiles({
        ...files,
        [name]: fileList[0],
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      // Create form data for file upload
      const formDataToSend = new FormData();

      // Add text fields
      Object.keys(formData).forEach(key => {
        if (formData[key]) {
          formDataToSend.append(key, formData[key]);
        }
      });

      // Add files
      Object.keys(files).forEach(key => {
        if (files[key]) {
          formDataToSend.append(key, files[key]);
        }
      });

      // Update profile
      const updatedProfile = await stationOwnerService.updateProfile(formDataToSend);
      setSuccess('Profile updated successfully!');

      // Call the callback to update the profile in the parent component
      if (onProfileUpdate) {
        onProfileUpdate(updatedProfile);
      }
    } catch (err) {
      console.error('Profile update error:', err);

      if (typeof err === 'object' && err !== null) {
        // Handle object errors by converting to string
        const errorMessage = Object.entries(err)
          .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`)
          .join('; ');
        setError(errorMessage || 'Failed to update profile. Please try again.');
      } else {
        // Default error message
        setError(err.message || 'Failed to update profile. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="profile-update-container">
      <div className="dashboard-header">
        <h1>
          Mengedmate Profile
          {profile && profile.verification_status === 'verified' && (
            <span className="verified-badge">
              <i className="fas fa-check-circle"></i> Verified
            </span>
          )}
        </h1>
        <p>Update your business information and documents</p>
      </div>

      <div className="profile-card">
        {error && <div className="profile-error">{error}</div>}
        {success && <div className="profile-success">{success}</div>}

        <form onSubmit={handleSubmit} className="profile-form">
          {profile && profile.verification_status === 'verified' && (
            <div className="verification-status-banner">
              <i className="fas fa-shield-alt"></i>
              <div className="verification-status-content">
                <h3>Verified Station Owner</h3>
                <p>Your account has been verified by our team. You can now add and manage charging stations.</p>
              </div>
            </div>
          )}

          <div className="form-section-title">Business Information</div>

          <div className="form-group">
            <label htmlFor="company_name">Company Name*</label>
            <input
              type="text"
              id="company_name"
              name="company_name"
              value={formData.company_name}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="business_registration_number">Business Registration Number*</label>
            <input
              type="text"
              id="business_registration_number"
              name="business_registration_number"
              value={formData.business_registration_number}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="website">Website (Optional)</label>
            <input
              type="url"
              id="website"
              name="website"
              placeholder="https://example.com"
              value={formData.website}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label htmlFor="description">Company Description (Optional)</label>
            <textarea
              id="description"
              name="description"
              rows="4"
              value={formData.description}
              onChange={handleChange}
            ></textarea>
          </div>

          <div className="form-section-title">Verification Documents</div>

          <div className="form-group">
            <label htmlFor="business_license">Business License</label>
            <input
              type="file"
              id="business_license"
              name="business_license"
              onChange={handleFileChange}
              className="file-input"
            />
            {profile && profile.business_license && (
              <div className="file-uploaded">
                <i className="fas fa-check-circle"></i> File uploaded
              </div>
            )}
            <small>Upload a copy of your business license (PDF, JPG, PNG)</small>
          </div>

          <div className="form-group">
            <label htmlFor="id_proof">ID Proof</label>
            <input
              type="file"
              id="id_proof"
              name="id_proof"
              onChange={handleFileChange}
              className="file-input"
            />
            {profile && profile.id_proof && (
              <div className="file-uploaded">
                <i className="fas fa-check-circle"></i> File uploaded
              </div>
            )}
            <small>Upload a copy of your ID (PDF, JPG, PNG)</small>
          </div>

          <div className="form-group">
            <label htmlFor="utility_bill">Utility Bill</label>
            <input
              type="file"
              id="utility_bill"
              name="utility_bill"
              onChange={handleFileChange}
              className="file-input"
            />
            {profile && profile.utility_bill && (
              <div className="file-uploaded">
                <i className="fas fa-check-circle"></i> File uploaded
              </div>
            )}
            <small>Upload a recent utility bill as proof of address (PDF, JPG, PNG)</small>
          </div>

          <button type="submit" className="profile-button" disabled={loading}>
            {loading ? 'Updating...' : 'Update Profile'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default StationOwnerProfileUpdate;

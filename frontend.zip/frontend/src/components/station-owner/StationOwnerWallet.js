import React from 'react';
import './StationOwner.css';

const StationOwnerWallet = () => {
  return (
    <div className="wallet-container">
      <div className="dashboard-header">
        <h1>Wallet</h1>
        <p>Manage your Mengedmate earnings and transactions</p>
      </div>

      <div className="coming-soon">
        <i className="fas fa-wallet"></i>
        <h2>Wallet Coming Soon</h2>
        <p>The wallet feature is under development. You'll soon be able to track earnings, view transaction history, and withdraw funds.</p>

        <div className="feature-preview">
          <h3>Upcoming Features:</h3>
          <ul>
            <li><i className="fas fa-chart-line"></i> Earnings Dashboard</li>
            <li><i className="fas fa-history"></i> Transaction History</li>
            <li><i className="fas fa-money-bill-wave"></i> Withdrawal Options</li>
            <li><i className="fas fa-file-invoice-dollar"></i> Invoices and Reports</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default StationOwnerWallet;

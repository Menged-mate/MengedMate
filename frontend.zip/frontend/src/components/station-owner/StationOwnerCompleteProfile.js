import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import stationOwnerService from '../../services/stationOwnerService';
import authService from '../../services/authService';
import '../auth/Auth.css';
import './StationOwner.css';

const StationOwnerCompleteProfile = () => {
  const [formData, setFormData] = useState({
    company_name: '',
    business_registration_number: '',
    website: '',
    description: '',
  });
  const [files, setFiles] = useState({
    business_license: null,
    id_proof: null,
    utility_bill: null,
  });
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingProfile, setLoadingProfile] = useState(true);

  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is authenticated
    if (!authService.isAuthenticated()) {
      navigate('/login');
      return;
    }

    // Fetch station owner profile
    const fetchProfile = async () => {
      try {
        const profileData = await stationOwnerService.getProfile();
        setProfile(profileData);

        // Pre-fill form data
        setFormData({
          company_name: profileData.company_name || '',
          business_registration_number: profileData.business_registration_number || '',
          website: profileData.website || '',
          description: profileData.description || '',
        });

        // Check if profile is already completed and verified
        if (profileData.is_profile_completed) {
          if (profileData.verification_status === 'verified') {
            navigate('/station-owner/dashboard');
          }
        }
      } catch (err) {
        console.error('Error fetching profile:', err);
        setError('Failed to load profile. Please try again.');
      } finally {
        setLoadingProfile(false);
      }
    };

    fetchProfile();
  }, [navigate]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    setFiles({ ...files, [e.target.name]: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      // Create form data for file upload
      const formDataToSend = new FormData();

      // Add text fields
      Object.keys(formData).forEach(key => {
        if (formData[key]) {
          formDataToSend.append(key, formData[key]);
        }
      });

      // Add files
      Object.keys(files).forEach(key => {
        if (files[key]) {
          formDataToSend.append(key, files[key]);
        }
      });

      // Update profile
      await stationOwnerService.updateProfile(formDataToSend);

      setSuccess('Profile updated successfully! Your account is now pending verification.');

      // Refresh profile data
      const updatedProfile = await stationOwnerService.getProfile();
      setProfile(updatedProfile);

      // Navigate to pending verification page after 2 seconds
      setTimeout(() => {
        navigate('/station-owners/pending-verification');
      }, 2000);
    } catch (err) {
      console.error('Profile update error:', err);

      if (typeof err === 'object' && err !== null) {
        // Handle object errors by converting to string
        const errorMessage = Object.entries(err)
          .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`)
          .join('; ');
        setError(errorMessage || 'Failed to update profile. Please try again.');
      } else {
        // Default error message
        setError(err.message || 'Failed to update profile. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  if (loadingProfile) {
    return (
      <div className="auth-container">
        <div className="auth-card">
          <div className="loading-spinner">Loading profile...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="auth-container">
      <div className="auth-card profile-card">
        <div className="auth-header">
          <div className="auth-logo">
            <i className="fas fa-charging-station" style={{ fontSize: '48px', color: '#4a6cf7' }}></i>
          </div>
          <h2>Complete Your Profile</h2>
          <p>Please provide the required information to verify your account</p>
        </div>

        {error && <div className="auth-error">{error}</div>}
        {success && <div className="auth-success">{success}</div>}

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label htmlFor="company_name">Company Name*</label>
            <input
              type="text"
              id="company_name"
              name="company_name"
              value={formData.company_name}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="business_registration_number">Business Registration Number*</label>
            <input
              type="text"
              id="business_registration_number"
              name="business_registration_number"
              value={formData.business_registration_number}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="website">Website (Optional)</label>
            <input
              type="url"
              id="website"
              name="website"
              placeholder="https://example.com"
              value={formData.website}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label htmlFor="description">Company Description (Optional)</label>
            <textarea
              id="description"
              name="description"
              rows="4"
              value={formData.description}
              onChange={handleChange}
            ></textarea>
          </div>

          <div className="form-section-title">Required Documents</div>

          <div className="form-group">
            <label htmlFor="business_license">Business License*</label>
            <input
              type="file"
              id="business_license"
              name="business_license"
              onChange={handleFileChange}
              required={!profile.business_license}
              className="file-input"
            />
            {profile.business_license && (
              <div className="file-uploaded">
                <i className="fas fa-check-circle"></i> File uploaded
              </div>
            )}
            <small>Upload a copy of your business license (PDF, JPG, PNG)</small>
          </div>

          <div className="form-group">
            <label htmlFor="id_proof">ID Proof*</label>
            <input
              type="file"
              id="id_proof"
              name="id_proof"
              onChange={handleFileChange}
              required={!profile.id_proof}
              className="file-input"
            />
            {profile.id_proof && (
              <div className="file-uploaded">
                <i className="fas fa-check-circle"></i> File uploaded
              </div>
            )}
            <small>Upload a copy of your ID (PDF, JPG, PNG)</small>
          </div>

          <div className="form-group">
            <label htmlFor="utility_bill">Utility Bill*</label>
            <input
              type="file"
              id="utility_bill"
              name="utility_bill"
              onChange={handleFileChange}
              required={!profile.utility_bill}
              className="file-input"
            />
            {profile.utility_bill && (
              <div className="file-uploaded">
                <i className="fas fa-check-circle"></i> File uploaded
              </div>
            )}
            <small>Upload a recent utility bill as proof of address (PDF, JPG, PNG)</small>
          </div>

          <button type="submit" className="auth-button" disabled={loading}>
            {loading ? 'Submitting...' : 'Submit for Verification'}
          </button>
        </form>

        <div className="auth-footer">
          <button className="back-button" onClick={() => navigate('/dashboard')}>
            <i className="fas fa-arrow-left"></i> Back to Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};

export default StationOwnerCompleteProfile;

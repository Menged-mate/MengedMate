import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import authService from '../../services/authService';
import './Auth.css';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const { email, password } = formData;

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await authService.login(email, password);
      console.log('Login response:', response);

      // Check if the user is a station owner
      const user = authService.getCurrentUser();
      console.log('Current user:', user);

      // If the user has a station_owner property, they are a station owner
      if (user && user.is_station_owner === true) {
        console.log('User is a station owner');
        // Check if the station owner has completed their profile
        try {
          const stationOwnerService = require('../../services/stationOwnerService').default;
          const profileData = await stationOwnerService.getProfile();
          console.log('Station owner profile:', profileData);

          if (!profileData.is_profile_completed) {
            navigate('/station-owners/complete-profile');
          } else if (profileData.verification_status === 'pending') {
            navigate('/station-owners/pending-verification');
          } else {
            // Verified station owner, navigate to station owner dashboard
            navigate('/station-owners/dashboard');
          }
        } catch (profileErr) {
          console.error('Error fetching station owner profile:', profileErr);
          navigate('/station-owners/complete-profile');
        }
      } else {
        // Regular user, navigate to dashboard
        console.log('User is a regular user');
        navigate('/dashboard');
      }
    } catch (err) {
      console.error('Login error:', err);

      if (err.message === 'Email not verified. Please verify your email first.') {
        navigate('/verify-email', { state: { email } });
      } else if (typeof err === 'object' && err !== null) {
        // Handle object errors by converting to string
        const errorMessage = Object.entries(err)
          .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`)
          .join('; ');
        setError(errorMessage || 'Login failed. Please check your credentials.');
      } else {
        // Default error message
        setError(err.message || 'Login failed. Please check your credentials.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGuestContinue = () => {
    // Handle guest login or continue as guest
    navigate('/dashboard');
  };

  const handleGoogleLogin = () => {
    // Handle Google login
    alert('Google login not implemented yet');
  };

  const handleAppleLogin = () => {
    // Handle Apple login
    alert('Apple login not implemented yet');
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-header">
          <div className="auth-logo">
            <i className="fas fa-charging-station" style={{ fontSize: '48px', color: '#4a6cf7' }}></i>
          </div>
          <h2>Welcome Back!</h2>
          <p>Please sign in to continue</p>
        </div>

        {error && <div className="auth-error">{error}</div>}

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="Enter your email"
              value={email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              placeholder="Enter your password"
              value={password}
              onChange={handleChange}
              required
            />
            <div className="forgot-password">
              <Link to="/forgot-password">Forgot password?</Link>
            </div>
          </div>

          <button type="submit" className="auth-button" disabled={loading}>
            {loading ? 'Signing In...' : 'Login'}
          </button>
        </form>

        <div className="auth-divider">
          <span>Or continue with</span>
        </div>

        <div className="social-login">
          <button className="social-button google" onClick={handleGoogleLogin}>
            <i className="fab fa-google"></i> Google
          </button>
          <button className="social-button apple" onClick={handleAppleLogin}>
            <i className="fab fa-apple"></i> Apple
          </button>
        </div>

        <button className="guest-button" onClick={handleGuestContinue}>
          Continue as Guest
        </button>

        <div className="auth-footer">
          Don't have an account? <Link to="/register">Sign up</Link>
        </div>
        <div className="auth-footer station-owner-link">
          Are you a station owner? <Link to="/station-owners/register">Register as Station Owner</Link>
        </div>
      </div>
    </div>
  );
};

export default Login;

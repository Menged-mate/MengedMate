import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import authService from '../../services/authService';
import './Auth.css';

const VerifyEmail = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);
  const [resendSuccess, setResendSuccess] = useState(false);

  useEffect(() => {
    // Get email from location state if available
    if (location.state && location.state.email) {
      setEmail(location.state.email);
    }
  }, [location]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await authService.verifyEmail(email, verificationCode);
      // Navigate to dashboard after successful verification
      navigate('/dashboard');
    } catch (err) {
      console.error('Verification error:', err);

      if (typeof err === 'object' && err !== null) {
        // Handle object errors by converting to string
        const errorMessage = Object.entries(err)
          .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`)
          .join('; ');
        setError(errorMessage || 'Verification failed. Please check your code and try again.');
      } else {
        // Default error message
        setError(err.message || 'Verification failed. Please check your code and try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleResendCode = async () => {
    setError('');
    setResendLoading(true);
    setResendSuccess(false);

    try {
      await authService.resendVerification(email);
      setResendSuccess(true);
    } catch (err) {
      console.error('Resend verification error:', err);

      if (typeof err === 'object' && err !== null) {
        // Handle object errors by converting to string
        const errorMessage = Object.entries(err)
          .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`)
          .join('; ');
        setError(errorMessage || 'Failed to resend verification code. Please try again.');
      } else {
        // Default error message
        setError(err.message || 'Failed to resend verification code. Please try again.');
      }
    } finally {
      setResendLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-header">
          <div className="auth-logo">
            <i className="fas fa-charging-station" style={{ fontSize: '48px', color: '#4a6cf7' }}></i>
          </div>
          <h2>Verify Your Email</h2>
          <p>Enter the verification code sent to your email</p>
        </div>

        {error && <div className="auth-error">{error}</div>}
        {resendSuccess && (
          <div className="auth-success">
            Verification code has been resent to your email.
          </div>
        )}

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              required
              disabled={location.state && location.state.email}
            />
          </div>

          <div className="form-group">
            <label htmlFor="verificationCode">Verification Code</label>
            <input
              type="text"
              id="verificationCode"
              value={verificationCode}
              onChange={(e) => setVerificationCode(e.target.value)}
              placeholder="Enter 6-digit code"
              required
              maxLength="6"
            />
          </div>

          <button type="submit" className="auth-button" disabled={loading}>
            {loading ? 'Verifying...' : 'Verify Email'}
          </button>
        </form>

        <div className="resend-code">
          Didn't receive the code?{' '}
          <button
            className="resend-button"
            onClick={handleResendCode}
            disabled={resendLoading}
          >
            {resendLoading ? 'Sending...' : 'Resend Code'}
          </button>
        </div>

        <div className="auth-footer">
          <button className="back-button" onClick={() => navigate('/login')}>
            Back to Login
          </button>
        </div>
      </div>
    </div>
  );
};

export default VerifyEmail;

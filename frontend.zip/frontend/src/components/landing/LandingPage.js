import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './LandingPage.css';

const LandingPage = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);

  useEffect(() => {
    // Set loaded state after a small delay for animations
    const timer = setTimeout(() => {
      setIsLoaded(true);
    }, 100);

    // Add scroll event listener
    const handleScroll = () => {
      setScrollPosition(window.scrollY);
    };
    window.addEventListener('scroll', handleScroll);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Calculate parallax effects based on scroll position
  const heroOpacity = Math.max(1 - scrollPosition / 700, 0);
  const heroTransform = `translateY(${scrollPosition * 0.4}px)`;

  return (
    <div className="landing-page">
      {/* Hero Section */}
      <section 
        className="hero-section" 
        style={{ opacity: heroOpacity, transform: heroTransform }}
      >
        <div className={`hero-content ${isLoaded ? 'loaded' : ''}`}>
          <div className="hero-logo">
            <i className="fas fa-charging-station"></i>
          </div>
          <h1 className="hero-title">Mengedmate</h1>
          <p className="hero-subtitle">Find EV Charging Stations Anywhere, Anytime</p>
          <div className="hero-buttons">
            <Link to="/login" className="btn btn-primary">
              <i className="fas fa-sign-in-alt"></i> Login
            </Link>
            <Link to="/register" className="btn btn-secondary">
              <i className="fas fa-user-plus"></i> Register
            </Link>
          </div>
        </div>
        <div className="hero-scroll-indicator">
          <span>Scroll to explore</span>
          <i className="fas fa-chevron-down"></i>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <div className="section-header">
          <h2>Why Choose Mengedmate?</h2>
          <p>The ultimate platform for electric vehicle owners and charging station operators</p>
        </div>
        <div className="features-grid">
          <div className="feature-card">
            <div className="feature-icon">
              <i className="fas fa-map-marked-alt"></i>
            </div>
            <h3>Find Stations Easily</h3>
            <p>Locate charging stations near you with our interactive map and filtering options</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">
              <i className="fas fa-bolt"></i>
            </div>
            <h3>Real-Time Availability</h3>
            <p>Check station availability and charging speeds before you arrive</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">
              <i className="fas fa-route"></i>
            </div>
            <h3>Plan Your Journey</h3>
            <p>Calculate routes with charging stops based on your vehicle's range</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">
              <i className="fas fa-user-check"></i>
            </div>
            <h3>Verified Stations</h3>
            <p>Trust our verified station owners with quality badges</p>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="how-it-works-section">
        <div className="section-header">
          <h2>How It Works</h2>
          <p>Getting started with Mengedmate is easy</p>
        </div>
        <div className="steps-container">
          <div className="step">
            <div className="step-number">1</div>
            <div className="step-content">
              <h3>Create an Account</h3>
              <p>Sign up and verify your email to access all features</p>
            </div>
          </div>
          <div className="step">
            <div className="step-number">2</div>
            <div className="step-content">
              <h3>Set Up Your Profile</h3>
              <p>Add your vehicle details and connector type</p>
            </div>
          </div>
          <div className="step">
            <div className="step-number">3</div>
            <div className="step-content">
              <h3>Find Charging Stations</h3>
              <p>Search for compatible stations near you or along your route</p>
            </div>
          </div>
          <div className="step">
            <div className="step-number">4</div>
            <div className="step-content">
              <h3>Charge and Go</h3>
              <p>Enjoy hassle-free charging with real-time updates</p>
            </div>
          </div>
        </div>
      </section>

      {/* Station Owners Section */}
      <section className="station-owners-section">
        <div className="section-content">
          <h2>Are You a Station Owner?</h2>
          <p>Join our network of charging station providers and grow your business</p>
          <ul className="benefits-list">
            <li><i className="fas fa-check-circle"></i> Increase visibility to EV owners</li>
            <li><i className="fas fa-check-circle"></i> Manage your stations efficiently</li>
            <li><i className="fas fa-check-circle"></i> Get verified status for more trust</li>
            <li><i className="fas fa-check-circle"></i> Access analytics and insights</li>
          </ul>
          <Link to="/station-owner/register" className="btn btn-accent">
            Register as Station Owner
          </Link>
        </div>
        <div className="section-image">
          <div className="image-container">
            <i className="fas fa-charging-station"></i>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="cta-content">
          <h2>Ready to Join the EV Revolution?</h2>
          <p>Start finding charging stations today with Mengedmate</p>
          <div className="cta-buttons">
            <Link to="/register" className="btn btn-primary">
              Get Started Now
            </Link>
            <Link to="/about" className="btn btn-outline">
              Learn More
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="landing-footer">
        <div className="footer-content">
          <div className="footer-logo">
            <i className="fas fa-charging-station"></i>
            <span>Mengedmate</span>
          </div>
          <div className="footer-links">
            <div className="footer-column">
              <h4>Company</h4>
              <ul>
                <li><Link to="/about">About Us</Link></li>
                <li><Link to="/contact">Contact</Link></li>
                <li><Link to="/careers">Careers</Link></li>
              </ul>
            </div>
            <div className="footer-column">
              <h4>Resources</h4>
              <ul>
                <li><Link to="/blog">Blog</Link></li>
                <li><Link to="/help">Help Center</Link></li>
                <li><Link to="/faq">FAQ</Link></li>
              </ul>
            </div>
            <div className="footer-column">
              <h4>Legal</h4>
              <ul>
                <li><Link to="/terms">Terms of Service</Link></li>
                <li><Link to="/privacy">Privacy Policy</Link></li>
                <li><Link to="/cookies">Cookie Policy</Link></li>
              </ul>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; {new Date().getFullYear()} Mengedmate. All rights reserved.</p>
          <div className="social-links">
            <a href="#" className="social-link"><i className="fab fa-facebook-f"></i></a>
            <a href="#" className="social-link"><i className="fab fa-twitter"></i></a>
            <a href="#" className="social-link"><i className="fab fa-instagram"></i></a>
            <a href="#" className="social-link"><i className="fab fa-linkedin-in"></i></a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;

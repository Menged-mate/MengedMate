import React from 'react';
import './StationOwner.css';

const StationOwnerSettings = () => {
  return (
    <div className="settings-container">
      <div className="dashboard-header">
        <h1>Settings</h1>
        <p>Manage your Mengedmate account settings and preferences</p>
      </div>

      <div className="coming-soon">
        <i className="fas fa-cogs"></i>
        <h2>Settings Coming Soon</h2>
        <p>We're working on implementing the settings feature. Check back later!</p>
      </div>

      <div className="feature-preview">
        <h3>Upcoming Settings Features</h3>
        <ul>
          <li><i className="fas fa-bell"></i> Notification preferences</li>
          <li><i className="fas fa-globe"></i> Language and region</li>
          <li><i className="fas fa-shield-alt"></i> Privacy and security</li>
          <li><i className="fas fa-palette"></i> Theme customization</li>
        </ul>
      </div>
    </div>
  );
};

export default StationOwnerSettings;

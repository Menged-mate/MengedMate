import React from 'react';
import './StationOwner.css';

const StationOwnerWallet = () => {
  return (
    <div className="wallet-container">
      <div className="dashboard-header">
        <h1>Wallet</h1>
        <p>Manage your Mengedmate earnings and transactions</p>
      </div>

      <div className="coming-soon">
        <i className="fas fa-wallet"></i>
        <h2>Wallet Coming Soon</h2>
        <p>We're working on implementing the wallet feature. Check back later!</p>
      </div>

      <div className="feature-preview">
        <h3>Upcoming Wallet Features</h3>
        <ul>
          <li><i className="fas fa-money-bill-wave"></i> Track your earnings</li>
          <li><i className="fas fa-chart-line"></i> View transaction history</li>
          <li><i className="fas fa-file-invoice-dollar"></i> Generate invoices</li>
          <li><i className="fas fa-credit-card"></i> Multiple payment methods</li>
        </ul>
      </div>
    </div>
  );
};

export default StationOwnerWallet;

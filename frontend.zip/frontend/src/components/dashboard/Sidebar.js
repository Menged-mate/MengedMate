import React from 'react';
import './Dashboard.css';

const Sidebar = ({ activeTab, setActiveTab, handleLogout, user }) => {
  return (
    <div className="dashboard-sidebar">
      <div className="sidebar-header">
        <div className="app-logo">
          <i className="fas fa-charging-station"></i>
          <span>EV Finder</span>
        </div>
      </div>
      
      <div className="sidebar-user">
        <div className="user-avatar">
          {user?.first_name ? user.first_name.charAt(0) : ''}
          {user?.last_name ? user.last_name.charAt(0) : ''}
        </div>
        <div className="user-info">
          <h3>{user?.first_name} {user?.last_name}</h3>
          <p>{user?.email}</p>
        </div>
      </div>
      
      <nav className="sidebar-nav">
        <ul>
          <li 
            className={activeTab === 'profile' ? 'active' : ''} 
            onClick={() => setActiveTab('profile')}
          >
            <i className="fas fa-user"></i>
            <span>My Profile</span>
          </li>
          <li 
            className={activeTab === 'stations' ? 'active' : ''} 
            onClick={() => setActiveTab('stations')}
          >
            <i className="fas fa-charging-station"></i>
            <span>Charging Stations</span>
          </li>
          <li 
            className={activeTab === 'favorites' ? 'active' : ''} 
            onClick={() => setActiveTab('favorites')}
          >
            <i className="fas fa-heart"></i>
            <span>My Favorites</span>
          </li>
          <li 
            className={activeTab === 'settings' ? 'active' : ''} 
            onClick={() => setActiveTab('settings')}
          >
            <i className="fas fa-cog"></i>
            <span>Settings</span>
          </li>
        </ul>
      </nav>
      
      <div className="sidebar-footer">
        <button className="logout-button" onClick={handleLogout}>
          <i className="fas fa-sign-out-alt"></i>
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import authService from '../../services/authService';
import './Dashboard.css';
import Navbar from './Navbar';
import ProfileUpdate from './ProfileUpdate';
import ChangePassword from './ChangePassword';

const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('profile');

  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is authenticated
    if (!authService.isAuthenticated()) {
      navigate('/login');
      return;
    }

    // Get current user data
    const currentUser = authService.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
      setLoading(false);
    } else {
      // If user data is not in localStorage, fetch it from API
      fetchUserProfile();
    }
  }, [navigate]);

  const fetchUserProfile = async () => {
    try {
      const userData = await authService.getUserProfile();
      setUser(userData);
    } catch (error) {
      console.error('Error fetching user profile:', error);
      // If there's an error fetching the profile, redirect to login
      authService.logout();
      navigate('/login');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await authService.logout();
    } catch (error) {
      console.error('Error logging out:', error);
    } finally {
      // Always navigate to login page, even if there was an error
      navigate('/login');
    }
  };

  const handleProfileUpdate = (updatedUser) => {
    setUser(updatedUser);
  };

  if (loading) {
    return (
      <div className="dashboard-loading">
        <div className="spinner"></div>
        <p>Loading dashboard...</p>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        handleLogout={handleLogout}
        user={user}
      />

      <div className="dashboard-content">
        <div className="dashboard-main">
          {activeTab === 'profile' && (
            <>
              <div className="dashboard-header">
                <h1>My Profile</h1>
                <p>Manage your personal information</p>
              </div>
              <ProfileUpdate
                user={user}
                onProfileUpdate={handleProfileUpdate}
              />
            </>
          )}

          {activeTab === 'password' && (
            <>
              <div className="dashboard-header">
                <h1>Change Password</h1>
                <p>Update your password to keep your account secure</p>
              </div>
              <ChangePassword />
            </>
          )}

          {activeTab === 'stations' && (
            <>
              <div className="dashboard-header">
                <h1>Charging Stations</h1>
                <p>Find EV charging stations near you</p>
              </div>
              <div className="coming-soon">
                <i className="fas fa-charging-station"></i>
                <h2>Charging Stations</h2>
                <p>This feature is coming soon!</p>
              </div>
            </>
          )}

          {activeTab === 'favorites' && (
            <>
              <div className="dashboard-header">
                <h1>My Favorites</h1>
                <p>Your saved charging stations</p>
              </div>
              <div className="coming-soon">
                <i className="fas fa-heart"></i>
                <h2>My Favorites</h2>
                <p>This feature is coming soon!</p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

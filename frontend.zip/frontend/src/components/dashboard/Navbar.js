import React, { useState } from 'react';
import './Dashboard.css';

const Navbar = ({ activeTab, setActiveTab, handleLogout, user }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
    // Close user menu if it's open
    if (userMenuOpen) setUserMenuOpen(false);
  };

  const toggleUserMenu = () => {
    setUserMenuOpen(!userMenuOpen);
    // Close mobile menu if it's open
    if (mobileMenuOpen) setMobileMenuOpen(false);
  };

  const handleTabClick = (tab) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
    setUserMenuOpen(false);
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <div className="navbar-logo">
          <i className="fas fa-charging-station"></i>
          <span>EV Finder</span>
        </div>

        {/* Desktop Navigation */}
        <div className="navbar-links">
          <ul>
            <li
              className={activeTab === 'stations' ? 'active' : ''}
              onClick={() => handleTabClick('stations')}
            >
              <i className="fas fa-charging-station"></i>
              <span>Charging Stations</span>
            </li>
            <li
              className={activeTab === 'favorites' ? 'active' : ''}
              onClick={() => handleTabClick('favorites')}
            >
              <i className="fas fa-heart"></i>
              <span>Favorites</span>
            </li>
          </ul>
        </div>

        {/* User Menu */}
        <div className="navbar-user">
          <div className="user-avatar" onClick={toggleUserMenu}>
            {user?.first_name ? user.first_name.charAt(0) : ''}
            {user?.last_name ? user.last_name.charAt(0) : ''}
          </div>

          {userMenuOpen && (
            <div className="user-dropdown">
              <div className="user-info">
                <h3>{user?.first_name} {user?.last_name}</h3>
                <p>{user?.email}</p>
              </div>
              <ul>
                <li
                  className={activeTab === 'profile' ? 'active' : ''}
                  onClick={() => handleTabClick('profile')}
                >
                  <i className="fas fa-user"></i>
                  <span>My Profile</span>
                </li>
                <li
                  className={activeTab === 'password' ? 'active' : ''}
                  onClick={() => handleTabClick('password')}
                >
                  <i className="fas fa-key"></i>
                  <span>Change Password</span>
                </li>
                <li onClick={() => {
                  // Close the dropdown menu first
                  setUserMenuOpen(false);
                  // Then handle logout
                  handleLogout();
                }}>
                  <i className="fas fa-sign-out-alt"></i>
                  <span>Logout</span>
                </li>
              </ul>
            </div>
          )}
        </div>

        {/* Mobile Menu Button */}
        <div className="mobile-menu-button" onClick={toggleMobileMenu}>
          <i className={mobileMenuOpen ? "fas fa-times" : "fas fa-bars"}></i>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="mobile-menu">
          <ul>
            <li
              className={activeTab === 'stations' ? 'active' : ''}
              onClick={() => handleTabClick('stations')}
            >
              <i className="fas fa-charging-station"></i>
              <span>Charging Stations</span>
            </li>
            <li
              className={activeTab === 'favorites' ? 'active' : ''}
              onClick={() => handleTabClick('favorites')}
            >
              <i className="fas fa-heart"></i>
              <span>Favorites</span>
            </li>
            <li
              className={activeTab === 'profile' ? 'active' : ''}
              onClick={() => handleTabClick('profile')}
            >
              <i className="fas fa-user"></i>
              <span>My Profile</span>
            </li>
            <li
              className={activeTab === 'password' ? 'active' : ''}
              onClick={() => handleTabClick('password')}
            >
              <i className="fas fa-key"></i>
              <span>Change Password</span>
            </li>
            <li onClick={() => {
              // Close the mobile menu first
              setMobileMenuOpen(false);
              // Then handle logout
              handleLogout();
            }}>
              <i className="fas fa-sign-out-alt"></i>
              <span>Logout</span>
            </li>
          </ul>
        </div>
      )}
    </nav>
  );
};

export default Navbar;

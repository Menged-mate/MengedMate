import React, { useState, useEffect } from 'react';
import authService from '../../services/authService';
import './Dashboard.css';

const ProfileUpdate = ({ user, onProfileUpdate }) => {
  const [formData, setFormData] = useState({
    first_name: user?.first_name || '',
    last_name: user?.last_name || '',
    email: user?.email || '',
    phone_number: user?.phone_number || '',
    address: user?.address || '',
    city: user?.city || '',
    state: user?.state || '',
    zip_code: user?.zip_code || '',
    ev_battery_capacity_kwh: user?.ev_battery_capacity_kwh || '',
    ev_connector_type: user?.ev_connector_type || 'none',
  });

  // EV connector type options
  const connectorTypes = [
    { value: 'type1', label: 'Type 1 (J1772)' },
    { value: 'type2', label: 'Type 2 (Mennekes)' },
    { value: 'ccs1', label: 'CCS Combo 1' },
    { value: 'ccs2', label: 'CCS Combo 2' },
    { value: 'chademo', label: 'CHAdeMO' },
    { value: 'tesla', label: 'Tesla' },
    { value: 'other', label: 'Other' },
    { value: 'none', label: 'None' },
  ];

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Update form data when user prop changes
  useEffect(() => {
    if (user) {
      setFormData({
        first_name: user.first_name || '',
        last_name: user.last_name || '',
        email: user.email || '',
        phone_number: user.phone_number || '',
        address: user.address || '',
        city: user.city || '',
        state: user.state || '',
        zip_code: user.zip_code || '',
        ev_battery_capacity_kwh: user.ev_battery_capacity_kwh || '',
        ev_connector_type: user.ev_connector_type || 'none',
      });
    }
  }, [user]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const updatedUser = await authService.updateProfile(formData);
      onProfileUpdate(updatedUser);
      setSuccess('Profile updated successfully!');
    } catch (err) {
      console.error('Profile update error:', err);

      if (typeof err === 'object' && err !== null) {
        // Handle object errors by converting to string
        const errorMessage = Object.entries(err)
          .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`)
          .join('; ');
        setError(errorMessage || 'Failed to update profile. Please try again.');
      } else {
        // Default error message
        setError(err.message || 'Failed to update profile. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="profile-update-container">
      <div className="profile-card">
        <div className="profile-header">
          <h2>Update Your Profile</h2>
          <p>Manage your personal information</p>
        </div>

        {error && <div className="profile-error">{error}</div>}
        {success && <div className="profile-success">{success}</div>}

        <form onSubmit={handleSubmit} className="profile-form">
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="first_name">First Name</label>
              <input
                type="text"
                id="first_name"
                name="first_name"
                value={formData.first_name}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="last_name">Last Name</label>
              <input
                type="text"
                id="last_name"
                name="last_name"
                value={formData.last_name}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="email">Email Address</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              disabled
            />
            <small>Email cannot be changed</small>
          </div>

          <div className="form-group">
            <label htmlFor="phone_number">Phone Number</label>
            <input
              type="tel"
              id="phone_number"
              name="phone_number"
              value={formData.phone_number}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label htmlFor="address">Address</label>
            <input
              type="text"
              id="address"
              name="address"
              value={formData.address}
              onChange={handleChange}
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="city">City</label>
              <input
                type="text"
                id="city"
                name="city"
                value={formData.city}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label htmlFor="state">State</label>
              <input
                type="text"
                id="state"
                name="state"
                value={formData.state}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label htmlFor="zip_code">ZIP Code</label>
              <input
                type="text"
                id="zip_code"
                name="zip_code"
                value={formData.zip_code}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="form-section-title">EV Information</div>

          <div className="form-group">
            <label htmlFor="ev_battery_capacity_kwh">EV Battery Capacity (kWh)</label>
            <input
              type="number"
              id="ev_battery_capacity_kwh"
              name="ev_battery_capacity_kwh"
              value={formData.ev_battery_capacity_kwh}
              onChange={handleChange}
              step="0.1"
              min="0"
              placeholder="Enter your EV battery capacity"
            />
            <small>Leave empty if not applicable</small>
          </div>

          <div className="form-group">
            <label htmlFor="ev_connector_type">EV Connector Type</label>
            <select
              id="ev_connector_type"
              name="ev_connector_type"
              value={formData.ev_connector_type}
              onChange={handleChange}
            >
              {connectorTypes.map((type) => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
          </div>

          <button type="submit" className="profile-button" disabled={loading}>
            {loading ? 'Updating...' : 'Update Profile'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ProfileUpdate;

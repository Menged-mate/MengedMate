import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import './App.css';

// Landing Page
import LandingPage from './components/landing/LandingPage';

// Auth Components
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import VerifyEmail from './components/auth/VerifyEmail';
import ForgotPassword from './components/auth/ForgotPassword';
import ResetPassword from './components/auth/ResetPassword';

// Dashboard Component
import Dashboard from './components/dashboard/Dashboard';

// Station Owner Components
import StationOwnerRegister from './components/station-owner/StationOwnerRegister';
import StationOwnerVerifyEmail from './components/station-owner/StationOwnerVerifyEmail';
import StationOwnerCompleteProfile from './components/station-owner/StationOwnerCompleteProfile';
import StationOwnerPendingVerification from './components/station-owner/StationOwnerPendingVerification';
import StationOwnerDashboard from './components/station-owner/StationOwnerDashboard';

// Auth Service
import authService from './services/authService';

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const isAuthenticated = authService.isAuthenticated();
  return isAuthenticated ? children : <Navigate to="/login" />;
};

// Route that redirects authenticated users away from auth pages
const AuthRoute = ({ children }) => {
  const isAuthenticated = authService.isAuthenticated();

  if (isAuthenticated) {
    // If authenticated, redirect to appropriate dashboard
    if (isStationOwner()) {
      return <Navigate to="/station-owners/dashboard" />;
    } else {
      return <Navigate to="/dashboard" />;
    }
  }

  // If not authenticated, show the auth page
  return children;
};

// Check if user is a station owner
const isStationOwner = () => {
  try {
    const user = authService.getCurrentUser();
    // We'll check if the user has a station_owner property
    // This will be added by the backend when a station owner logs in
    return user && user.is_station_owner === true;
  } catch (error) {
    console.error('Error checking if user is station owner:', error);
    return false;
  }
};

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          {/* Auth Routes - redirect authenticated users */}
          <Route path="/login" element={<AuthRoute><Login /></AuthRoute>} />
          <Route path="/register" element={<AuthRoute><Register /></AuthRoute>} />
          <Route path="/verify-email" element={<AuthRoute><VerifyEmail /></AuthRoute>} />
          <Route path="/forgot-password" element={<AuthRoute><ForgotPassword /></AuthRoute>} />
          <Route path="/reset-password" element={<AuthRoute><ResetPassword /></AuthRoute>} />

          {/* Station Owner Routes - support both singular and plural paths */}
          <Route path="/station-owner/register" element={<AuthRoute><StationOwnerRegister /></AuthRoute>} />
          <Route path="/station-owners/register" element={<AuthRoute><StationOwnerRegister /></AuthRoute>} />
          <Route path="/station-owner/verify-email" element={<AuthRoute><StationOwnerVerifyEmail /></AuthRoute>} />
          <Route path="/station-owners/verify-email" element={<AuthRoute><StationOwnerVerifyEmail /></AuthRoute>} />
          <Route
            path="/station-owner/complete-profile"
            element={
              <ProtectedRoute>
                <StationOwnerCompleteProfile />
              </ProtectedRoute>
            }
          />
          <Route
            path="/station-owners/complete-profile"
            element={
              <ProtectedRoute>
                <StationOwnerCompleteProfile />
              </ProtectedRoute>
            }
          />
          <Route
            path="/station-owner/pending-verification"
            element={
              <ProtectedRoute>
                <StationOwnerPendingVerification />
              </ProtectedRoute>
            }
          />
          <Route
            path="/station-owners/pending-verification"
            element={
              <ProtectedRoute>
                <StationOwnerPendingVerification />
              </ProtectedRoute>
            }
          />
          <Route
            path="/station-owners/dashboard"
            element={
              <ProtectedRoute>
                <StationOwnerDashboard />
              </ProtectedRoute>
            }
          />

          {/* Protected Routes */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />

          {/* Landing Page */}
          <Route path="/" element={<LandingPage />} />

          {/* Default Route - redirect to landing page */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

import api from './api';

// Auth API endpoint prefix
const AUTH_ENDPOINT = 'auth/';

// Register user
const register = async (email, password, firstName, lastName) => {
  try {
    const response = await api.post(`${AUTH_ENDPOINT}register/`, {
      email,
      password,
      password2: password,
      first_name: firstName,
      last_name: lastName,
    });
    return response.data;
  } catch (error) {
    console.error('Registration error details:', error);

    // Handle different error response formats
    if (error.response && error.response.data) {
      // If the error response contains data, return it
      return Promise.reject(error.response.data);
    } else if (error.message) {
      // If there's an error message, return it
      return Promise.reject({ message: error.message });
    } else {
      // Default error message
      return Promise.reject({ message: 'Registration failed. Please try again.' });
    }
  }
};

// Verify email with code
const verifyEmail = async (email, verificationCode) => {
  try {
    const response = await api.post(`${AUTH_ENDPOINT}verify-email/`, {
      email,
      verification_code: verificationCode,
    });
    if (response.data.token) {
      localStorage.setItem('token', response.data.token);
    }
    return response.data;
  } catch (error) {
    console.error('Verification error details:', error);

    // Handle different error response formats
    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Email verification failed. Please try again.' });
    }
  }
};

// Login user
const login = async (email, password) => {
  try {
    const response = await api.post(`${AUTH_ENDPOINT}login/`, {
      email,
      password,
    });
    if (response.data.token) {
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('user', JSON.stringify(response.data.user));
    }
    return response.data;
  } catch (error) {
    console.error('Login error details:', error);

    // Handle different error response formats
    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Login failed. Please try again.' });
    }
  }
};

// Logout user
const logout = async () => {
  try {
    await api.post(`${AUTH_ENDPOINT}logout/`);
    return { message: 'Logout successful' };
  } catch (error) {
    console.error('Logout error:', error);
    // Even if the API call fails, we'll consider it a "successful" logout
    // from the client perspective
  } finally {
    // Always clear local storage regardless of API success/failure
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }
  return { message: 'Logged out' };
};

// Resend verification code
const resendVerification = async (email) => {
  try {
    const response = await api.post(`${AUTH_ENDPOINT}resend-verification/`, {
      email,
    });
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: 'Failed to resend verification code' };
  }
};

// Get current user
const getCurrentUser = () => {
  const userStr = localStorage.getItem('user');
  if (userStr) {
    return JSON.parse(userStr);
  }
  return null;
};

// Check if user is authenticated
const isAuthenticated = () => {
  return !!localStorage.getItem('token');
};

// Get user profile
const getUserProfile = async () => {
  try {
    const response = await api.get(`${AUTH_ENDPOINT}profile/`);
    // Update the user in localStorage
    if (response.data) {
      localStorage.setItem('user', JSON.stringify(response.data));
    }
    return response.data;
  } catch (error) {
    console.error('Get profile error details:', error);

    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Failed to get user profile. Please try again.' });
    }
  }
};

// Update user profile
const updateProfile = async (profileData) => {
  try {
    // Handle numeric fields properly
    const dataToSend = { ...profileData };

    // Convert empty string to null for numeric fields
    if (dataToSend.ev_battery_capacity_kwh === '') {
      dataToSend.ev_battery_capacity_kwh = null;
    }

    console.log('Sending profile update:', dataToSend);

    const response = await api.put(`${AUTH_ENDPOINT}profile/`, dataToSend);
    console.log('Profile update response:', response.data);

    // Update the user in localStorage
    if (response.data) {
      localStorage.setItem('user', JSON.stringify(response.data));
    }
    return response.data;
  } catch (error) {
    console.error('Update profile error details:', error);

    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Failed to update profile. Please try again.' });
    }
  }
};

// Change password
const changePassword = async (currentPassword, newPassword) => {
  try {
    const response = await api.put(`${AUTH_ENDPOINT}change-password/`, {
      current_password: currentPassword,
      new_password: newPassword,
    });
    return response.data;
  } catch (error) {
    console.error('Change password error details:', error);

    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Failed to change password. Please try again.' });
    }
  }
};

// Forgot password - request password reset
const forgotPassword = async (email) => {
  try {
    const response = await api.post(`${AUTH_ENDPOINT}forgot-password/`, {
      email,
    });
    return response.data;
  } catch (error) {
    console.error('Forgot password error details:', error);

    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Failed to send password reset email. Please try again.' });
    }
  }
};

// Reset password with token
const resetPassword = async (token, email, newPassword) => {
  try {
    const response = await api.post(`${AUTH_ENDPOINT}reset-password/`, {
      token,
      email,
      new_password: newPassword,
    });
    return response.data;
  } catch (error) {
    console.error('Reset password error details:', error);

    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Failed to reset password. Please try again.' });
    }
  }
};

const authService = {
  register,
  verifyEmail,
  login,
  logout,
  resendVerification,
  getCurrentUser,
  isAuthenticated,
  getUserProfile,
  updateProfile,
  changePassword,
  forgotPassword,
  resetPassword,
};

export default authService;

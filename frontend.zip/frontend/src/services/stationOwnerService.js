import api from './api';

// Station owner API endpoint prefix
const STATION_OWNER_ENDPOINT = 'station-owners/';

// Register as a station owner
const register = async (userData) => {
  try {
    const response = await api.post(`${STATION_OWNER_ENDPOINT}register/`, {
      email: userData.email,
      password: userData.password,
      password2: userData.password2,
      first_name: userData.first_name,
      last_name: userData.last_name,
      company_name: userData.company_name,
    });
    return response.data;
  } catch (error) {
    console.error('Registration error details:', error);

    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Registration failed. Please try again.' });
    }
  }
};

// Verify email with verification code
const verifyEmail = async (email, verificationCode) => {
  try {
    const response = await api.post(`${STATION_OWNER_ENDPOINT}verify-email/`, {
      email,
      verification_code: verificationCode,
    });
    return response.data;
  } catch (error) {
    console.error('Email verification error details:', error);

    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Email verification failed. Please try again.' });
    }
  }
};

// Resend verification code
const resendVerificationCode = async (email) => {
  try {
    // Import authService to use its resendVerification method
    const authService = require('./authService').default;
    return await authService.resendVerification(email);
  } catch (error) {
    console.error('Resend verification error details:', error);

    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Failed to resend verification code. Please try again.' });
    }
  }
};

// Get station owner profile
const getProfile = async () => {
  try {
    const response = await api.get(`${STATION_OWNER_ENDPOINT}profile/`);
    return response.data;
  } catch (error) {
    console.error('Get profile error details:', error);

    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Failed to get profile. Please try again.' });
    }
  }
};

// Update station owner profile
const updateProfile = async (formData) => {
  try {
    const response = await api.patch(`${STATION_OWNER_ENDPOINT}profile/`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  } catch (error) {
    console.error('Update profile error details:', error);

    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Failed to update profile. Please try again.' });
    }
  }
};

// Get all charging stations for the station owner
const getStations = async () => {
  try {
    const response = await api.get('stations/');
    return response.data;
  } catch (error) {
    console.error('Get stations error details:', error);

    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Failed to get stations. Please try again.' });
    }
  }
};

// Create a new charging station
const createStation = async (stationData) => {
  try {
    const response = await api.post('stations/', stationData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  } catch (error) {
    console.error('Create station error details:', error);

    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    } else if (error.message) {
      return Promise.reject({ message: error.message });
    } else {
      return Promise.reject({ message: 'Failed to create station. Please try again.' });
    }
  }
};

const stationOwnerService = {
  register,
  verifyEmail,
  resendVerificationCode,
  getProfile,
  updateProfile,
  getStations,
  createStation,
};

export default stationOwnerService;

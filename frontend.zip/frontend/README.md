# Mengedmate Frontend

This is the React frontend for the Mengedmate EV Charging Station Locator application.

## Development

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

### Available Scripts

In the project directory, you can run:

- `npm start`: Runs the app in development mode at [http://localhost:3000](http://localhost:3000)
- `npm test`: Launches the test runner in interactive watch mode
- `npm run build`: Builds the app for production to the `build` folder

## Deploying to Vercel

### Prerequisites

1. A [Vercel](https://vercel.com) account
2. The [Vercel CLI](https://vercel.com/docs/cli) (optional, for local development)
3. Your backend API already deployed and accessible

### Deployment Steps

#### Option 1: Deploy from the Vercel Dashboard (Recommended)

1. Push your code to a Git repository (GitHub, GitLab, or Bitbucket)
2. Log in to your Vercel account
3. Click "New Project"
4. Import your Git repository
5. Configure the project:
   - Set the Framework Preset to "Create React App"
   - Set the Root Directory to "frontend" (if your repository contains both frontend and backend)
   - Add the following environment variable:
     - `REACT_APP_API_URL`: The URL of your backend API (e.g., https://your-backend-api.com)
6. Click "Deploy"

#### Option 2: Deploy using the Vercel CLI

1. Install the Vercel CLI:

   ```
   npm install -g vercel
   ```

2. Navigate to the frontend directory:

   ```
   cd frontend
   ```

3. Log in to Vercel:

   ```
   vercel login
   ```

4. Deploy to Vercel:

   ```
   vercel --prod
   ```

5. When prompted, set the environment variable:
   - `REACT_APP_API_URL`: The URL of your backend API

### Configuring Environment Variables

After deployment, you can update environment variables in the Vercel dashboard:

1. Go to your project in the Vercel dashboard
2. Click on "Settings" > "Environment Variables"
3. Add or update the `REACT_APP_API_URL` variable with your backend URL
4. Click "Save"
5. Redeploy your application for the changes to take effect

### Troubleshooting

If you encounter CORS issues:

1. Ensure your backend's CORS settings include your Vercel domain
2. Update the `CORS_ALLOWED_ORIGINS` in your backend settings to include your Vercel domain (e.g., `https://mengedmate.vercel.app`)
3. Redeploy your backend with the updated CORS settings

### Custom Domains

To use a custom domain:

1. Go to your project in the Vercel dashboard
2. Click on "Settings" > "Domains"
3. Add your custom domain
4. Follow the instructions to configure DNS settings
5. Update your backend's CORS settings to include your custom domain
